
  var person = prompt(" Please enter your name : ");
  document.writeln(" Hello " + person + " !How are you today? ");

